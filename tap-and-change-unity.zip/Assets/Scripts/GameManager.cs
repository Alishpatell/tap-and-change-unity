using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public Button Play;
    public Button Exit;
    public Button Back;

    void Start()
    {
        if(Play != null)
            Play.onClick.AddListener(OnPlay);
        if(Exit != null)
            Exit.onClick.AddListener(OnExit);
        if(Back != null)
            Back.onClick.AddListener(OnBack);
    }

    void OnPlay()
    {
        SceneManager.LoadScene("PlayScene");
    }

    void OnExit()
    {
        // Application.Exit();
        Debug.Log("Game Closed");
    }

    void OnBack()
    {
        SceneManager.LoadScene("HomeScene");
    }
}
