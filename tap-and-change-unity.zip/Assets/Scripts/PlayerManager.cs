using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerManager : MonoBehaviour
{
    public GameObject PlayerOnTop;
    public GameObject Player;
    public TextMeshProUGUI Score;
    public Button Restart;
    public float scoreSpeed = 10f; // score increases by this value per second

    private bool isTop = true;
    private bool isGameOver = false;
    private float count = 0f;

    void Start()
    {
        PlayerOnTop.SetActive(true);
        Player.SetActive(false);

        PlayerOnTop.GetComponent<PlayerCollision>().manager = this;
        Player.GetComponent<PlayerCollision>().manager = this;

        Restart.onClick.AddListener(RestartGame);

        Time.timeScale = 1f;
        isGameOver = false;
    }

    void Update()
    {
        if (isGameOver) return;

        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
        {
            isTop = !isTop;
            PlayerOnTop.SetActive(isTop);
            Player.SetActive(!isTop);
        }

        // Increase score like Subway Surfers — based on time and speed
        count += Time.deltaTime * scoreSpeed;

        UpdateScore();
    }

    public void GameOver()
    {
        isGameOver = true;
        Time.timeScale = 0f;

        PlayerOnTop.SetActive(false);
        Player.SetActive(false);
    }

    void UpdateScore()
    {
        Score.text = "Score: " + Mathf.FloorToInt(count).ToString();
    }

    void DestroyAllObstacles()
    {
        GameObject[] allObstacles = GameObject.FindGameObjectsWithTag("Obstacle");
        foreach (GameObject obstacle in allObstacles)
        {
            Destroy(obstacle);
        }
    }

    void RestartGame()
    {
        count = 0f;
        isGameOver = false;

        DestroyAllObstacles();
        PlayerOnTop.SetActive(true);
        Player.SetActive(false);

        isTop = true;
        Time.timeScale = 1f;
    }
}
