using UnityEngine;

public class ObstacleManager : MonoBehaviour
{
    public GameObject obstacleTop;             
    public GameObject obstacleBottom;          

    public Transform spawnPointTop;            
    public Transform spawnPointBottom;         

    public float minSpawnInterval = 0.2f;      
    public float maxSpawnInterval = 0.8f;      
    public float obstacleSpeed = 10f;           

    private float timer = 0f;
    private float nextSpawnTime;

    void Start()
    {
        nextSpawnTime = Random.Range(minSpawnInterval, maxSpawnInterval);
    }

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= nextSpawnTime)
        {
            SpawnObstacle();
            timer = 0f;
            nextSpawnTime = Random.Range(minSpawnInterval, maxSpawnInterval);
        }
    }

    void SpawnObstacle()
    {
        bool spawnTop = Random.value > 0.5f;

        if (spawnTop)
        {
            GameObject top = Instantiate(obstacleTop, spawnPointTop.position, Quaternion.identity);
            Rigidbody2D rb = top.GetComponent<Rigidbody2D>();
            if (rb != null)
                rb.velocity = Vector2.left * obstacleSpeed;

            Destroy(top, 7f);
        }
        else
        {
            GameObject bottom = Instantiate(obstacleBottom, spawnPointBottom.position, Quaternion.Euler(0f, 0f, 180f));
            Rigidbody2D rb = bottom.GetComponent<Rigidbody2D>();
            if (rb != null)
                rb.velocity = Vector2.left * obstacleSpeed;

            Destroy(bottom, 7f);
        }
    }
}