using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public PlayerManager manager;

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            manager.GameOver();
        }
    }
}
